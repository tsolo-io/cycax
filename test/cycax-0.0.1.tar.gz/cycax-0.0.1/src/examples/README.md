# CyCAx examples

## Installation
Copy there scripts to a directoy adjacent to where the code is checked out.
If you checked CyCAx out into ~/src/cycax then copy these scripts to ~/src/playpen.
Run `make install` in the example directory to install CyCAx.

## Build and test examples
Run `hatch build` in cycax checkout directory to create the Python package files.
Run `make` in the example directory to install and test the examples.
