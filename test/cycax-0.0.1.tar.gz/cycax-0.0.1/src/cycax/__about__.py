# SPDX-FileCopyrightText: 2023-present Martin Slabber <martin@tsolo.io>
#
# SPDX-License-Identifier: Apache-2.0
__version__ = "0.0.1"
